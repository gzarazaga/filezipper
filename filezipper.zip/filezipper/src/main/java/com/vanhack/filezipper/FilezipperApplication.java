package com.vanhack.filezipper;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FilezipperApplication {

	public static void main(String[] args) {
		SpringApplication.run(FilezipperApplication.class, args);
	}

}
