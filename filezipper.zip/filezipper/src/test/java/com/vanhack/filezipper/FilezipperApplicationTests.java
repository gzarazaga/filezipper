package com.vanhack.filezipper;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FilezipperApplicationTests {

	@Test
	void contextLoads() {
	}

}
